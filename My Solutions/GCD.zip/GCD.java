// Author: Shaan Barkat
package stdlib;
import stdlib.*;

public class GCD {
	
	public static int GCD(int a, int b){
		if (b == 0) {
			return a;
		}
		else {
			return GCD(b, a%b);
		}
	}

	public static void main(String[] args) {
		StdOut.print("Enter a: ");
		int a = Integer.parseInt(StdIn.readLine());
		StdOut.print("Enter b: ");
		int b = Integer.parseInt(StdIn.readLine());
		StdOut.printf("The GCD is: %,d",GCD(a,b));
	
		
	}

}
