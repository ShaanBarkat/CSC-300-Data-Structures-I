package orderedList;
//Author: Shaan Barkat
public class OrderedLinkedList<Item extends Comparable<? super Item>> {

	private class Node {
		private Item data;
		private Node next;

		public Node(Item data) {
			this.data = data;
			this.next = null;
		}

		public Item getData() {
			return this.data;
		}

		public Node getNext() {
			return this.next;
		}

		public void setData(Item data) {
			this.data = data;
		}

		public void setNext(Node next) {
			this.next = next;
		}
	}

	private Node head;

	public OrderedLinkedList() {
		head = null;
	}

	public void insert(Item newData) {
	        Node newNode= new Node(newData);
	        Node Previous = null;
	        Node Current=head;

	        while(true){
	            if(Current== null || newData.compareTo(Current.getData())<0){
	                newNode.setNext(Current);
	                if(Previous==null){
	                    head=newNode;
	                }
	                else{
	                    Previous.setNext(newNode);
	                }
	                return;
	            }
	            Previous=Current;
	            Current=Current.getNext();
	        }
	}

	public void remove(Item oldData) {
        Node Previous = null;
        Node Current = head;
        
        while (Current!= null){
            if(Current.getData().equals(oldData)){
                if(Previous == null){
                    head=head.getNext();
                }
                else{
                    Previous.setNext(Current.getNext());
                }
                return;
            }
            Previous = Current;
            Current = Current.getNext();
        }
	}

	public String toString() {
		String s = "[";
		boolean firstItem = true;
		for (Node current = head; current != null; current = current.getNext()) {
			if (firstItem) {
				firstItem = false;
				s += current.getData();
			} else {
				s += ", " + current.getData();
			}
		}
		s += "]";
		return s;
	}

}
