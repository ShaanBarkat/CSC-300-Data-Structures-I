package orderedList;
//Author: Shaan Barkat
import java.util.*;
import stdlib.*;

public class TestOLL {

    public static void main(String[] args) {
    OrderedLinkedList<String> linkedlist = new OrderedLinkedList<String>();
    
    linkedlist.insert("goodbye");
    
    linkedlist.insert("adios");
    
    linkedlist.insert("buenos dias");
    
    linkedlist.insert("bon jour");
    
    linkedlist.insert("adieu");
    
    linkedlist.insert("guten Tag");
    
    linkedlist.insert("hello");
    
    linkedlist.insert("auf Wiedersehen");
   
    StdOut.print(linkedlist);

        

    }

}
