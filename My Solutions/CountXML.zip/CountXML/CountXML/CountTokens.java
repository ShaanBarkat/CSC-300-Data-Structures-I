// 
// Decompiled by Procyon v0.5.36
// 

package parseXML;

import java.util.ArrayList;
import stdlib.StdIn;
import stdlib.StdOut;

public class CountTokens
{
    public static void main(final String[] args) {
        StdOut.print((Object)"Enter the file name:");
        final String file = StdIn.readLine();
        StdIn.fromFile(file);
        final ArrayList<XMLToken> ac = new ArrayList<XMLToken>();
        while (!StdIn.isEmpty()) {
            final String[] a = StdIn.readString().split(" ");
            for (int i = 0; i < a.length; ++i) {
                final XMLToken x = new XMLToken(a[i]);
                ac.add(x);
            }
        }
        int OpenT = 0;
        int CloseT = 0;
        int Str = 0;
        int MalformTok = 0;
        for (int j = 0; j < ac.size(); ++j) {
            if (ac.get(j).isTag()) {
                if (ac.get(j).isOpeningTag()) {
                    ++OpenT;
                }
                else if (ac.get(j).isClosingTag()) {
                    ++CloseT;
                }
                else {
                    ++MalformTok;
                }
            }
            else {
                ++Str;
            }
        }
        StdOut.println((Object)("Number of words in file: " + Str));
        StdOut.println((Object)("Number of XML OpenT in file: " + OpenT));
        StdOut.println((Object)("Number of XML CloseT in file: " + CloseT));
        StdOut.println((Object)("Number of XML MalformTok in file: " + MalformTok));
    }
}
