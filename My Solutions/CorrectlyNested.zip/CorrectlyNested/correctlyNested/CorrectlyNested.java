// 
// Decompiled by Procyon v0.5.36
// 

package correctlyNested;

import stdlib.StdIn;
import stdlib.StdOut;
import java.util.Stack;

public class CorrectlyNested
{
    public static boolean correct(final String str) {
        final Stack<Character> WStack = new Stack<Character>();
        for (int i = 0; i < str.length(); ++i) {
            if (str.charAt(i) == '(' || str.charAt(i) == '[' || str.charAt(i) == '{') {
                WStack.push(str.charAt(i));
            }
            else if (str.charAt(i) == ')' || str.charAt(i) == ']' || str.charAt(i) == '}') {
                if (WStack.isEmpty()) {
                    return false;
                }
                final char poop = WStack.pop();
                if (poop == '(' && str.charAt(i) != ')') {
                    return false;
                }
                if (poop == '[' && str.charAt(i) != ']') {
                    return false;
                }
                if (poop == '{' && str.charAt(i) != '{') {
                    return false;
                }
            }
        }
        return WStack.isEmpty();
    }
    
    public static void main(final String[] args) {
        StdOut.print((Object)"Enter a String:");
        final String words = StdIn.readString();
        StdOut.print(correct(words));
    }
}
