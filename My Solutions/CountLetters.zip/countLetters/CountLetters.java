//Author: Shaan Barkat
package countLetters;

import stdlib.*;

public class CountLetters {

	public static void main(String[] args) {
		int[] acc = new int[26];
		StdOut.print("Enter the name of the file: ");
		String x = StdIn.readString();
		StdIn.fromFile(x);
		String lett = StdIn.readAll().toLowerCase();
		for(int i = 0; lett.length()>i; i++){
			char f = lett.charAt(i);
			if(Character.isLowerCase(f)){
				acc[f-'a']++;
			}
		}
		for(int ans=0; ans < acc.length; ans++){
			StdOut.printf("%c\t%,5d\n",(ans+'a'),acc[ans]);
		}
	}

}
