// 
// Decompiled by Procyon v0.5.36
// 

package music;

import stdlib.StdAudio;

public class Chord
{
    private double[] freqs;
    private double dur;
    
    public Chord(final double dur, final double[] freqs) {
        this.freqs = new double[0];
        this.dur = dur;
        this.freqs = new double[freqs.length];
        for (int i = 0; i < freqs.length; ++i) {
            this.freqs[i] = freqs[i];
        }
    }
    
    public void play() {
        this.playChord(this.dur, this.freqs);
    }
    
    @Override
    public String toString() {
        String tot = new String();
        tot = String.valueOf(tot) + "[" + this.dur + ";";
        for (int i = 0; i < this.freqs.length; ++i) {
            tot = String.valueOf(tot) + " " + this.freqs[i];
        }
        tot = String.valueOf(tot) + "]";
        return tot;
    }
    
    private void playChord(final double duration, final double[] frequencies) {
        final int sliceCount = (int)(44100.0 * duration);
        final double[] slices = new double[sliceCount + 1];
        for (int i = 0; i <= sliceCount; ++i) {
            double chord = 0.0;
            for (final double frequency : frequencies) {
                chord += Math.sin(6.283185307179586 * i * frequency / 44100.0);
            }
            slices[i] = chord / frequencies.length;
        }
        StdAudio.play(slices);
    }
}
