// 
// Decompiled by Procyon v0.5.36
// 

package music;

import stdlib.StdIn;
import stdlib.StdOut;
import java.util.ArrayList;

public class PlayMusic
{
    public static void main(final String[] args) {
        final ArrayList<Chord> chords = new ArrayList<Chord>();
        StdOut.print((Object)"Enter Filename: ");
        final String file = StdIn.readLine();
        StdIn.fromFile(file);
        while (!StdIn.isEmpty()) {
            final double dur = Double.parseDouble(StdIn.readLine());
            final String freq = StdIn.readLine();
            final String[] freqStrings = freq.split(" ");
            final double[] freqs = new double[freqStrings.length];
            for (int i = 0; i < freqStrings.length; ++i) {
                final double diff = Double.parseDouble(freqStrings[i]);
                freqs[i] = diff;
            }
            final Chord nChord = new Chord(dur, freqs);
            chords.add(nChord);
        }
        for (int j = 0; j < chords.size(); ++j) {
            StdOut.println((Object)chords.get(j));
            chords.get(j).play();
        }
    }
}
