// 
// Decompiled by Procyon v0.5.36
// 

package printCalendar;

import algs12.Date;
import stdlib.StdIn;
import stdlib.StdOut;

public class PrintCalendar
{
    public static void main(final String[] args) {
        int i = 0;
        StdOut.print((Object)"Enter a start day: ");
        final String R = StdIn.readString();
        Date Begin = new Date(R);
        StdOut.print((Object)"Enter an end date: ");
        final String W = StdIn.readString();
        final Date End = new Date(W);
        if (Begin.isBefore(End)) {
            while (Begin.isBefore(End)) {
                if (++i % 8 == 0) {
                    StdOut.println();
                }
                else {
                    StdOut.print((Object)(Begin + "\t"));
                }
                Begin = Begin.next();
            }
            StdOut.print((Object)Begin);
        }
        else if (Begin.equals((Object)End)) {
            StdOut.print((Object)Begin);
        }
        else {
            StdOut.print((Object)"Error: Start Day Is After End Date");
        }
    }
}
