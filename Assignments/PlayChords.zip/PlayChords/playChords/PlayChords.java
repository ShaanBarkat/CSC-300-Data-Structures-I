// 
// Decompiled by Procyon v0.5.36
// 

package playChords;

import stdlib.StdIn;
import stdlib.StdAudio;

public class PlayChords
{
    public static void playChord(final double duration, final double[] frequencies) {
        final int sliceCount = (int)(44100.0 * duration);
        final double[] slices = new double[sliceCount + 1];
        for (int i = 0; i <= sliceCount; ++i) {
            double chord = 0.0;
            for (final double frequency : frequencies) {
                chord += Math.sin(6.283185307179586 * i * frequency / 44100.0);
            }
            slices[i] = chord / frequencies.length;
        }
        StdAudio.play(slices);
    }
    
    public static void main(final String[] args) {
        StdIn.fromFile("data/chords.txt");
        while (!StdIn.isEmpty()) {
            final double[] a = new double[2];
            final double d = StdIn.readDouble();
            for (int i = 0; i < 2; ++i) {
                a[i] = StdIn.readDouble();
            }
            playChord(d, a);
        }
    }
}
