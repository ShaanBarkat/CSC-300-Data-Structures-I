// 
// Decompiled by Procyon v0.5.36
// 

package midterm;

import java.util.Collection;
import java.util.Arrays;
import stdlib.StdOut;
import algs13.Stack;
import java.util.ArrayList;

public class Midterm
{
    public static int floorlog(int n) {
        int acc;
        for (acc = 0; n >= 1; n /= 2, ++acc) {}
        return acc;
    }
    
    public static ArrayList<Double> squareRootList(final ArrayList<Double> list) {
        for (int i = 0; i < list.size(); ++i) {
            double s = list.get(i);
            s = Math.sqrt(s);
            list.set(i, s);
        }
        return list;
    }
    
    public static long falling(final long n, final long e) {
        if (e == 0L) {
            return 1L;
        }
        return n * falling(n - 1L, e - 1L);
    }
    
    public static Double sumBelowLimit(final ArrayList<Double> list, final Double limit) {
        double total = 0.0;
        for (int i = 0; i < list.size(); ++i) {
            if (list.get(i) < limit) {
                total += list.get(i);
            }
        }
        return total;
    }
    
    public static int productOfEvens(final ArrayList<Integer> list) {
        int total = 1;
        if (list.isEmpty()) {
            return 1;
        }
        for (int i = 0; i < list.size(); ++i) {
            if (list.get(i) % 2 == 0) {
                total *= list.get(i);
            }
        }
        return total;
    }
    
    public static String[] reverse(final String[] list) {
        final Stack<String> stack = (Stack<String>)new Stack();
        for (int i = 0; i < list.length; ++i) {
            final char ch = (char)list.length;
            stack.push((Object)list[i]);
        }
        for (int i = 0; i < list.length; ++i) {
            list[i] = (String)stack.pop();
        }
        return list;
    }
    
    public static void main(final String[] args) {
        StdOut.println(floorlog(32));
        StdOut.println(floorlog(35));
        StdOut.println(floorlog(64));
        StdOut.println(floorlog(2048));
        final Double[] sqarray = { 3.5, 4.7, 10.1, 25.0, 76.34, 100.01, 256.0 };
        ArrayList<Double> dlist = new ArrayList<Double>(Arrays.asList(sqarray));
        StdOut.println((Object)dlist);
        squareRootList(dlist);
        StdOut.println((Object)dlist);
        StdOut.println(falling(10L, 2L));
        StdOut.println(falling(52L, 6L));
        dlist = new ArrayList<Double>();
        StdOut.println((Object)sumBelowLimit(dlist, 50.0));
        final Double[] sbarray = { 45.3, 12.4, 50.1, 32.8, 75.5, 49.9, 50.0 };
        dlist = new ArrayList<Double>(Arrays.asList(sbarray));
        StdOut.println((Object)sumBelowLimit(dlist, 50.0));
        ArrayList<Integer> ilist = new ArrayList<Integer>();
        StdOut.println(productOfEvens(ilist));
        final Integer[] eparray1 = { 2, 3, 4, 9, 11, 12 };
        ilist = new ArrayList<Integer>(Arrays.asList(eparray1));
        StdOut.println(productOfEvens(ilist));
        final Integer[] eparray2 = { 7, 3, 53, 9, 11, 19 };
        ilist = new ArrayList<Integer>(Arrays.asList(eparray2));
        StdOut.println(productOfEvens(ilist));
        final String[] starray = { "hello", "how", "are", "you" };
        reverse(starray);
        StdOut.println((Object)Arrays.toString(starray));
    }
}
