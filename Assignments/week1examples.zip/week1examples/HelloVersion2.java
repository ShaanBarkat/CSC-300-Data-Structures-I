package week1examples;
import stdlib.*;

public class HelloVersion2 {

	public static void main(String[] args) {
		StdOut.println("Hello, World (version 2)!");

	}

}
