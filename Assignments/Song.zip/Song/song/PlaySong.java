// 
// Decompiled by Procyon v0.5.36
// 

package song;

import stdlib.StdIn;

public class PlaySong
{
    public static void main(final String[] args) {
        final Song song = new Song();
        StdIn.fromFile("data/march.txt");
        while (!StdIn.isEmpty()) {
            final double duration = StdIn.readDouble();
            final double frequency = StdIn.readDouble();
            song.addDuration(duration);
            song.addFrequency(frequency);
        }
        song.play();
    }
}
