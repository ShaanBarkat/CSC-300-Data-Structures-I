// 
// Decompiled by Procyon v0.5.36
// 

package song;

import stdlib.StdAudio;
import java.util.ArrayList;

public class Song
{
    private ArrayList<Double> dur;
    private ArrayList<Double> freq;
    
    public static void playTone(final double frequency, final double duration) {
        final int sliceCount = (int)(44100.0 * duration);
        final double[] slices = new double[sliceCount + 1];
        for (int i = 0; i <= sliceCount; ++i) {
            slices[i] = Math.sin(6.283185307179586 * i * frequency / 44100.0);
        }
        StdAudio.play(slices);
    }
    
    public Song() {
        this.dur = new ArrayList<Double>();
        this.freq = new ArrayList<Double>();
        this.dur.clear();
        this.freq.clear();
    }
    
    public void addFrequency(final double frequency) {
        this.freq.add(frequency);
    }
    
    public void addDuration(final double duration) {
        this.dur.add(duration);
    }
    
    public void play() {
        for (int i = 0; this.freq.size() > i; ++i) {
            playTone(this.freq.get(i), this.dur.get(i));
        }
        StdAudio.close();
    }
}
