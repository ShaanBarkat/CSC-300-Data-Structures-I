// Author: Shaan Barkat
package searchText;

import java.util.ArrayList;

import stdlib.*;

public class SearchText {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		int a = 0;
		StdOut.print("Enter the name of a textfile: ");
		String fName = StdIn.readLine();
		StdOut.print("Enter a search string: ");
		String sStr = StdIn.readLine();
		StdIn.fromFile(fName);
		while(!StdIn.isEmpty()){
			String fWord = StdIn.readString();
			list.add(fWord);
			
		}
		for(String i: list){
			if(i.contains(sStr)){
				StdOut.println(i.replaceAll("[^a-zA-Z]",""));
				a++;
				
			}
		}
		StdOut.printf("Number of words containing \"%s\":%d",sStr,a);
		}

	}

