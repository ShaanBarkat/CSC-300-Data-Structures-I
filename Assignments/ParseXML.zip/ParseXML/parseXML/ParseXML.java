// 
// Decompiled by Procyon v0.5.36
// 

package parseXML;

import algs13.Stack;
import stdlib.StdIn;
import stdlib.StdOut;

public class ParseXML
{
    public static void main(final String[] args) throws Exception {
        StdOut.print((Object)"Please enter the file name: ");
        StdIn.fromFile("data/" + StdIn.readLine() + ".txt");
        final String[] TokS = StdIn.readAllStrings();
        final XMLToken[] Tok = new XMLToken[TokS.length];
        for (int i = 0; i < TokS.length; ++i) {
            Tok[i] = new XMLToken(TokS[i]);
        }
        final Stack<String> Stack = (Stack<String>)new Stack();
        for (int j = 0; j < TokS.length; ++j) {
            if (Tok[j].isOpeningTag()) {
                StdOut.print((Object)Tok[j]);
                Stack.push((Object)Tok[j].getTagName());
            }
            else if (Tok[j].isClosingTag()) {
                StdOut.println((Object)TokS[j]);
                if (Stack.isEmpty()) {
                    throw new Exception1("found a closing tag with no matching opening tag");
                }
                final String n = (String)Stack.pop();
                if (!Tok[j].getTagName().equals(n)) {
                    throw new Exception2("found a closing tag that does not match its opening tag");
                }
            }
            else {
                StdOut.println((Object)TokS[j]);
            }
        }
        if (!Stack.isEmpty()) {
            throw new Exception3("there are opening tags with no matching closing tags");
        }
    }
}
