// 
// Decompiled by Procyon v0.5.36
// 

package parseXML;

public class XMLToken
{
    private String Tok;
    
    public XMLToken(final String token) {
        this.Tok = token;
    }
    
    public boolean isTag() {
        return this.Tok.length() >= 3 && this.Tok.charAt(0) == '<' && this.Tok.charAt(this.Tok.length() - 1) == '>';
    }
    
    public boolean isOpeningTag() {
        return this.Tok.matches("<\\w+>");
    }
    
    public boolean isClosingTag() {
        return this.Tok.matches("</\\w+>");
    }
    
    public String getTagName() {
        String ac = "";
        if (this.isTag()) {
            if (this.isOpeningTag()) {
                ac = this.Tok.substring(1, this.Tok.length() - 1);
            }
            else if (this.isClosingTag()) {
                ac = this.Tok.substring(1, this.Tok.length() - 2);
            }
        }
        return ac;
    }
}
