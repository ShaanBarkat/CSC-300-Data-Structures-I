// 
// Decompiled by Procyon v0.5.36
// 

package balancedParentheses;

import algs13.Stack;
import stdlib.StdIn;
import stdlib.StdOut;

public class BalancedParentheses
{
    public static void main(final String[] args) {
        StdOut.print((Object)"Enter a String: ");
        final String w = StdIn.readString();
        final Stack<Character> s = (Stack<Character>)new Stack();
        for (int i = 0; i < w.length(); ++i) {
            if (w.charAt(i) == '(') {
                s.push((Object)w.charAt(i));
            }
            else if (w.charAt(i) == ')') {
                if (!s.isEmpty()) {
                    s.pop();
                }
                else {
                    StdOut.printf("Not balanced right parentheses found", new Object[0]);
                    System.exit(0);
                }
            }
        }
        if (!s.isEmpty()) {
            StdOut.printf("Not balanced left paretheses found", new Object[0]);
        }
        else {
            StdOut.printf("The parentheses are balanced.", new Object[0]);
        }
    }
}
